'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, Route, Calculator, ScrollText, Car, Wrench, Stamp,
  BookOpen, FileText, Mail, Phone, GraduationCap, Sparkles, ChevronRight,
  Menu, X, CheckSquare, type LucideIcon
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/cn';

interface NavItem {
  href: string;
  icon: LucideIcon;
  label: string;
  code: string;
  badge?: 'hot' | 'premium' | 'demo';
}

const NAV_ITEMS: NavItem[] = [
  { href: '/app/dashboard',           icon: LayoutDashboard, label: 'Centro de control', code: '' },
  { href: '/app/ruta',                icon: Route,           label: 'Ruta de matriculación', code: 'M.01' },
  { href: '/app/simulador-576',       icon: Calculator,      label: 'Simulador 576', code: 'M.02', badge: 'hot' },
  { href: '/app/ficha-tecnica',       icon: ScrollText,          label: 'Ficha técnica 3D', code: 'M.03' },
  { href: '/app/checklist/antes-de-comprar', icon: CheckSquare, label: 'Antes de comprar', code: 'M.04' },
  { href: '/app/checklist/pre-itv',   icon: Wrench,          label: 'Checklist pre-ITV', code: 'M.05' },
  { href: '/app/recorrido-itv',       icon: Car,             label: 'Recorrido ITV', code: 'M.06', badge: 'hot' },
  { href: '/app/checklist/pre-dgt',   icon: Stamp,           label: 'Checklist pre-DGT', code: 'M.07' },
  { href: '/app/casos-practicos',     icon: BookOpen,        label: 'Casos prácticos', code: 'M.08' },
  { href: '/app/biblioteca',          icon: FileText,        label: 'Biblioteca docs.', code: 'M.09' },
  { href: '/app/plantillas-itv',      icon: Mail,            label: 'Plantillas ITV', code: 'M.10' },
  { href: '/app/acompanamiento',      icon: Phone,           label: 'Acompañamiento', code: 'M.11', badge: 'premium' },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-bg">
      {/* TOPBAR mobile */}
      <header className="lg:hidden sticky top-0 z-40 bg-surface border-b border-line h-14 px-4 flex items-center justify-between">
        <Link href="/app/dashboard" className="flex items-baseline gap-1.5">
          <span className="text-[10px] tracking-[0.22em] uppercase text-muted">Ivan ·</span>
          <span className="font-serif italic text-xl text-ink">Matricula</span>
          <span className="text-[11px] font-semibold text-accent">PRO</span>
        </Link>
        <button onClick={() => setMobileOpen(v => !v)} className="p-2">
          {mobileOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </header>

      <div className="flex">
        {/* SIDEBAR */}
        <aside
          className={cn(
            'fixed inset-y-0 left-0 z-30 w-[260px] bg-ink text-white transition-transform lg:translate-x-0 lg:static lg:flex-shrink-0',
            mobileOpen ? 'translate-x-0' : '-translate-x-full',
            'flex flex-col'
          )}
        >
          {/* Logo */}
          <div className="px-5 py-6 hidden lg:flex items-baseline gap-1.5 border-b border-white/5">
            <span className="text-[9.5px] tracking-[0.22em] uppercase text-muted">Ivan Imports ·</span>
            <span className="font-serif italic text-2xl text-white">Matricula</span>
            <span className="text-[11px] font-semibold text-accent">PRO</span>
          </div>

          {/* Nav */}
          <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-0.5">
            <div className="text-[9.5px] tracking-[0.22em] uppercase text-muted px-3 mb-2 mt-1">Curso activo</div>
            {NAV_ITEMS.map(item => {
              const Icon = item.icon;
              const isActive = pathname === item.href || (item.href !== '/app/dashboard' && pathname?.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}
                  className={cn(
                    'flex items-center gap-2.5 px-3 py-2 rounded-lg text-[12.5px] transition-colors group',
                    isActive ? 'bg-accent/15 text-white' : 'text-muted-soft hover:bg-white/5 hover:text-white'
                  )}>
                  <Icon size={14} className={cn('shrink-0', isActive ? 'text-accent' : 'text-muted')} />
                  <span className="flex-1 truncate">{item.label}</span>
                  {item.code && (
                    <span className={cn('text-[9px] font-mono shrink-0', isActive ? 'text-accent' : 'text-muted')}>{item.code}</span>
                  )}
                  {item.badge === 'hot' && <Sparkles size={10} className="text-accent shrink-0" />}
                  {item.badge === 'premium' && <span className="text-[8.5px] font-semibold text-accent shrink-0">PRO</span>}
                </Link>
              );
            })}

            <div className="text-[9.5px] tracking-[0.22em] uppercase text-muted px-3 mb-2 mt-6">Mis cursos</div>
            <Link href="/app/mis-cursos" onClick={() => setMobileOpen(false)}
              className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-[12.5px] text-muted-soft hover:bg-white/5 hover:text-white">
              <GraduationCap size={14} className="shrink-0 text-muted" />
              <span>Todos los cursos</span>
              <ChevronRight size={11} className="text-muted ml-auto" />
            </Link>
          </nav>

          {/* Footer sidebar */}
          <div className="px-3 pb-4 border-t border-white/5 pt-4">
            <Link href="/legal/aviso-formativo" className="text-[10.5px] leading-snug text-muted hover:text-white px-3 block">
              ⚠ Aviso formativo · No sustituye a ITV, DGT, Hacienda ni gestoría.
            </Link>
          </div>
        </aside>

        {/* Mobile overlay */}
        {mobileOpen && (
          <div className="fixed inset-0 bg-black/40 z-20 lg:hidden" onClick={() => setMobileOpen(false)} />
        )}

        {/* MAIN */}
        <main className="flex-1 min-w-0 min-h-screen">
          {children}
        </main>
      </div>
    </div>
  );
}
